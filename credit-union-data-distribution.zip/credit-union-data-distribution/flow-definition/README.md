# Flow definition

Place here the sanitized export (.zip) of the **demo copy** of the flow.

Before uploading, confirm that the files contain no real identifiers:
no company domains, no internal site URLs, no folder paths, no e-mail addresses and no real list names.
All values must be placeholders (for example `contoso.sharepoint.com`, `recipient@example.com`).
