# Key Power Automate expressions

All expressions below are used as written in the flow (Workflow Definition Language). Action names with spaces become underscores when referenced, for example `Get files - Date folder` becomes `Get_files_-_Date_folder`.

---

## 1. Dates

**Today in local time (Brazil), format `YYYYMMDD`**
```
convertTimeZone(utcNow(), 'UTC', 'E. South America Standard Time', 'yyyyMMdd')
```

**Start of the 7-day window**
```
convertTimeZone(addDays(utcNow(), -7), 'UTC', 'E. South America Standard Time', 'yyyyMMdd')
```

**Folder date `YYYYMMDD` to `DD/MM/YYYY` (used in the e-mail subject)**
```
concat(substring(variables('varReferenceDate'), 6, 2), '/', substring(variables('varReferenceDate'), 4, 2), '/', substring(variables('varReferenceDate'), 0, 4))
```
Pure text slicing. No date parsing, so it never fails on locale settings.

---

## 2. Selecting new folders

Filter array condition (left side, compared to `true`):
```
and(
  equals(item()?['{IsFolder}'], true),
  equals(length(item()?['{FilenameWithExtension}']), 8),
  startsWith(item()?['{FilenameWithExtension}'], '20'),
  greaterOrEquals(item()?['{FilenameWithExtension}'], variables('varCutoffDate')),
  greaterOrEquals(item()?['{FilenameWithExtension}'], variables('varWindowStart'))
)
```
Keeps only folders named `YYYYMMDD`, on or after the cutoff date and inside the rolling window. Because the names are `YYYYMMDD`, string comparison equals date comparison.

**Process folders from oldest to newest**
```
sort(body('Filter_-_New_folders'), '{FilenameWithExtension}')
```

---

## 3. Parsing the credit union code from the file name

Example: `Base Analitica - Collections - 20260928 - Coop 4037.xlsx`

```
trim(last(split(substring(variables('varFileName'), 0, lastIndexOf(variables('varFileName'), '.')), ' - Coop ')))
```

Step by step:
1. `lastIndexOf(..., '.')` finds the extension dot.
2. `substring(..., 0, position)` removes `.xlsx`.
3. `split(..., ' - Coop ')` splits into `["Base Analitica - Collections - 20260928", "4037"]`.
4. `last(...)` returns `4037`.
5. `trim(...)` removes stray spaces.

Deterministic and fully auditable. No AI involved.

---

## 4. Registry lookup

Get items filter query (OData), built as an expression:
```
concat('Title eq ''', variables('varCode'), '''')
```
Two single quotes inside a string produce one literal quote, so the result is `Title eq '4037'`.

**Recipients from the first match, empty if not found**
```
coalesce(first(body('Get_items_-_Registry')?['value'])?['Recipients'], '')
```
Note: lists created by importing an Excel file get internal column names such as `field_1`, `field_2`. Always confirm the internal name in the raw output of a test run.

---

## 5. Idempotency (duplicate prevention)

**Delivery key**
```
concat(variables('varReferenceDate'), '_', variables('varCode'))
```

**Log lookup filter**
```
concat('Title eq ''', variables('varReferenceDate'), '_', variables('varCode'), '''')
```

**Send condition (compared to `true`)**
```
and(
  greater(length(variables('varRecipients')), 0),
  equals(length(body('Get_items_-_Delivery_log')?['value']), 0)
)
```
Send only if there is at least one registered recipient and no previous delivery for the same key.

---

## 6. Safe test mode

**To**
```
if(variables('varTestMode'), variables('varTestEmail'), variables('varRecipients'))
```

**CC (no copies during tests)**
```
if(variables('varTestMode'), '', 'cc1@example.com;cc2@example.com')
```

**Subject**
```
concat(if(variables('varTestMode'), '[TEST] ', ''), 'Collections Base - Coop ', variables('varCode'), ' - ', variables('varFormattedDate'))
```

**Log status**
```
if(variables('varTestMode'), 'Test', 'Sent')
```

---

## 7. Audit fields

| Field | Expression |
|---|---|
| ProcessedAt / SentAt | `utcNow()` |
| FileId | `string(items('Apply_to_each_-_File')?['ID'])` |
| RunId | `workflow()?['run']?['name']` |

---

## 8. Attachment

| Field | Expression |
|---|---|
| Name | `variables('varFileName')` |
| Content | `body('Get_file_content')` |

The file content is taken by the identifier of the current loop item, so the attachment always matches the file whose name produced the credit union code.
