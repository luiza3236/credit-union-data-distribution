# Automated Collections Data Distribution for Credit Unions

Automated, audit-ready workflow that distributes sensitive collections data files to 30+ affiliated credit unions, built with **Microsoft Power Automate** and **SharePoint**.

> All identifiers in this repository (sites, folders, lists, e-mail addresses and institution names) are anonymized. No customer or institutional data is included.

![Architecture](docs/architecture.svg)

---

## Business problem

A credit union central receives, on business days, a folder of collections and debt-renegotiation data files. Each file belongs to one affiliated credit union and must be delivered to the people responsible for collections at that institution.

The distribution was done manually:

- at least **3 hours of manual work per day**
- high **operational risk**: each file contains sensitive customer information and must reach exactly the right institution
- **no audit trail** of who received what, and when
- folders do not arrive every day, and they arrive at different times

## Solution

A scheduled cloud flow that, every day:

1. Lists the date folders in the source library (folder names follow the `YYYYMMDD` pattern).
2. Selects only **new folders**: on or after a cutoff date and within a rolling 7-day window.
3. For each file in each new folder (pattern `Base Analitica - ... - YYYYMMDD - Coop NNNN.xlsx`):
   - extracts the credit union code from the file name with deterministic text rules
   - looks up the recipients in a **registry list**
   - checks the **delivery log** to make sure the file was not sent before
   - sends the file as an attachment to the registered recipients, with fixed copies to the central team
   - writes a record to the delivery log

## Design principles and controls

| Control | How it is implemented | Risk addressed |
|---|---|---|
| Deterministic routing | Credit union code parsed from the file name with text functions. No AI, no manual selection | Wrong file sent to the wrong institution |
| Single source of recipients | Recipients come only from a governed registry list | Sending to unregistered addresses |
| Idempotency | Unique key `YYYYMMDD_CODE` checked in the delivery log before every send | Duplicate deliveries on reruns |
| Audit trail | Every delivery logged with file name, code, recipients, status, timestamp and run ID | No evidence of who received what |
| Privacy by design | No file content stored in logs; secure inputs and outputs enabled on file and e-mail actions | Exposure of personal data in run history (LGPD) |
| Safe testing | Test mode variable redirects every e-mail to the operator and removes copies | Production data reaching recipients before validation |
| Sequential processing | Loops run with concurrency = 1 | Race conditions and mixed-up variables |
| Cutoff date + rolling window | Only folders on or after the cutoff and within 7 days are processed | Resending historical folders |

## Tech stack

- Microsoft Power Automate (scheduled cloud flow)
- SharePoint Online (document library and lists)
- Office 365 Outlook connector
- Power Automate expressions (Workflow Definition Language)

## Data model

**Registry list** (one row per credit union)

| Column | Type | Description |
|---|---|---|
| Code | Text (Title) | 4-digit credit union code |
| Name | Text | Credit union name |
| Recipients | Multi-line text | One or more e-mails separated by `;` |
| Active | Text | `Yes` / `No` |

**Delivery log** (one row per file delivered)

| Column | Type | Description |
|---|---|---|
| DeliveryKey | Text (Title) | `YYYYMMDD_CODE`, used for duplicate prevention |
| FileName | Text | Source file name |
| CooperativeCode | Text | Credit union code |
| ReferenceDate | Text | Folder date `YYYYMMDD` |
| ProcessedAt | Date and time | Processing timestamp |
| Recipients | Multi-line text | Addresses used |
| Status | Text | `Sent` or `Test` |
| SentAt | Date and time | Delivery timestamp |
| FileId | Text | Source file ID |
| RunId | Text | Power Automate run ID |
| Attempts | Number | Delivery attempts |

## Flow structure

```
Scheduled trigger (daily)
  Initialize variables (test mode, dates, cutoff, paths)
  Scope: list date folders in the source library
  Filter: new folders (YYYYMMDD, >= cutoff, within 7 days)
  For each folder (sorted, concurrency 1)
    Set reference date and formatted date
    Get files in the folder
    For each file (concurrency 1)
      Set file name
      Set credit union code (parsed from file name)
      Get registry item for the code
      Set recipients
      Get delivery log item for YYYYMMDD_CODE
      Condition: has recipients AND not delivered yet
        True:
          Get file content
          Send e-mail with attachment
          Create delivery log item
```

Key expressions are documented in [docs/expressions.md](docs/expressions.md).

## Results

- **3+ hours of manual work eliminated per day**
- **17 files delivered to 17 credit unions in under 30 seconds** on the first production run
- Full audit trail of every delivery
- Lower operational risk of misrouted sensitive data
- Time saved reinvested in team development, credit analysis and portfolio risk

## Lessons learned

- **Controls first, speed second.** The value of automation in credit operations comes from guarantees (right recipient, no duplicates, evidence), not only from time saved.
- **Deterministic rules beat AI when the pattern is known.** File names follow a fixed convention, so text functions are simpler, cheaper and fully auditable.
- **Design for reruns.** An idempotency key makes manual reruns and recovery safe.
- **Test mode is a control, not a convenience.** It allowed full end-to-end validation with real files without any data leaving the team.

## Roadmap

- [ ] File name validation (exact pattern, 4-digit code, date matching the folder)
- [ ] Recipient validation (format checks for every address)
- [ ] Error handling with Try / Catch / Finally scopes, so one failure never stops other deliveries
- [ ] Daily summary e-mail with delivered, skipped and failed items
- [ ] Sending from a shared departmental mailbox
- [ ] Migration of lists to the team site with restricted permissions

## Repository contents

| Path | Content |
|---|---|
| `README.md` | This case study |
| `docs/architecture.svg` | Architecture diagram |
| `docs/expressions.md` | Key Power Automate expressions, explained |
| `flow-definition/` | Sanitized export of a demo copy of the flow |

## Author

**Luiza De Souza Lisboa**
Credit Modeling Coordinator | Credit Risk, Data Governance and Process Automation

This repository is a case study. The production flow belongs to the employer and is not published. The flow definition provided here is a sanitized demo copy with placeholder values.
